#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QDebug"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter Painter(this);
    QPen Linepen(Qt::red);
    Linepen.setWidth(2);
    Painter.setPen(Linepen);
    QPoint P1;
    P1.setX(70);
    P1.setY(272);

    QPoint P2;// re nhanh
    P2.setX(360);
    P2.setY(272);
    Painter.drawLine(P1,P2);

    QPoint P3;//re nhanh
    P3.setX(550);
    P3.setY(272);
    Painter.drawLine(P2,P3);

    QPoint P4;
    P4.setX(730);
    P4.setY(272);
    Painter.drawLine(P3,P4);

    QPoint P5;
    P5.setX(550);
    P5.setY(202);
    Painter.drawLine(P3,P5);

    QPoint P6;
    P6.setX(730);
    P6.setY(202);
    Painter.drawLine(P5,P6);

    QPoint P7;
    P7.setX(550);
    P7.setY(132);
    Painter.drawLine(P5,P7);

    QPoint P8;
    P8.setX(730);
    P8.setY(132);
    Painter.drawLine(P7,P8);

    QPoint P9;
    P9.setX(550);
    P9.setY(62);
    Painter.drawLine(P7,P9);

    QPoint P10;
    P10.setX(730);
    P10.setY(62);
    Painter.drawLine(P9,P10);

    QPoint P31;
    P31.setX(550);
    P31.setY(342);
    Painter.drawLine(P3,P31);

    QPoint P32;
    P32.setX(730);
    P32.setY(342);
    Painter.drawLine(P31,P32);

    QPoint P33;
    P33.setX(550);
    P33.setY(412);
    Painter.drawLine(P31,P33);

    QPoint P34;
    P34.setX(730);
    P34.setY(412);
    Painter.drawLine(P33,P34);

    QPoint P35;
    P35.setX(550);
    P35.setY(482);
    Painter.drawLine(P33,P35);

    QPoint P36;
    P36.setX(730);
    P36.setY(482);
    Painter.drawLine(P35,P36);

    QPoint P11;
    P11.setX(360);
    P11.setY(672);
    Painter.drawLine(P2,P11);

    QPoint P12;
    P12.setX(70);
    P12.setY(672);
    Painter.drawLine(P11,P12);
    Painter.drawLine(P12,P1);

}

MainWindow::~MainWindow()
{
    delete ui;
}
