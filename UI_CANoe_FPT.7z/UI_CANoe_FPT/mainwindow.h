#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QtWidgets"
#include "QtCore"
#include "QtGui"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
private slots:
    void contextMenuRequested(const QPoint& point);
    void InsertButtonTrace();
    void InsertButtonStatic();
    void InsertButtonData();
    void InsertButtonLog();
    void InsertButtonGraphics();
protected:
    void paintEvent(QPaintEvent *event);

private:
    Ui::MainWindow *ui;

    QLayout *Layout;
    QWidget *Widget;
    QPushButton *Button[100],*ButtonConnecti[100];
    QPushButton *ButtonReal,*ButtonBranch;
    QPushButton *ButtonConnect,*ButtonConnect1,*ButtonConnect2,*ButtonConnect3,*ButtonConnect4,*ButtonConnect5;
    QPushButton *ButtonTrace,*ButtonData,*ButtonStatics,*ButtonLogging,*ButtonGraphics;
    QHBoxLayout *H_Layout,*H1_Layout,*H2_Layout,*H3_Layout,*H4_Layout,*H5_Layout,*H6_Layout;
    QVBoxLayout *V_Layout;

    QMenu *ShowMenu;
    QAction *InsertStaticwindow;
    QAction *InsertTraceWindow;
    QAction *InsertDataWindow;
    QAction *InsertLoggingWindow;
    QAction *InsertGraphicsWindow;
};

#endif // MAINWINDOW_H
