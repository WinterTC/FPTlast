#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    Widget = new QWidget(this);

    ButtonReal = new QPushButton(">>");
    ButtonReal->setFixedWidth(50);
    ButtonReal->setMaximumWidth(100);
    ButtonConnect = new QPushButton("icon");
    ButtonConnect->setFixedWidth(30);
    ButtonBranch = new QPushButton("Branching");

    H1_Layout = new QHBoxLayout;
    H1_Layout->addWidget(ButtonReal);
    H1_Layout->addWidget(ButtonConnect);
    H1_Layout->addWidget(ButtonBranch);

    H2_Layout = new QHBoxLayout;
    ButtonStatics = new QPushButton("Statics");
    ButtonConnect1 = new QPushButton("icon");
    ButtonConnect1->setFixedWidth(50);
    H2_Layout->addWidget(ButtonConnect1);
    H2_Layout->addWidget(ButtonStatics);

    H3_Layout = new QHBoxLayout;
    ButtonTrace = new QPushButton("Trace");
    ButtonConnect2 = new QPushButton("icon");
    ButtonConnect2->setFixedWidth(50);
    H3_Layout->addWidget(ButtonConnect2);
    H3_Layout->addWidget(ButtonTrace);

    H4_Layout = new QHBoxLayout;
    ButtonLogging = new QPushButton("Logging");
    ButtonConnect3 = new QPushButton("icon");
    ButtonConnect3->setFixedWidth(50);
    H4_Layout->addWidget(ButtonConnect3);
    H4_Layout->addWidget(ButtonLogging);

    H5_Layout = new QHBoxLayout;
    ButtonData = new QPushButton("Data");
    ButtonConnect4 = new QPushButton("icon");
    ButtonConnect4->setFixedWidth(50);
    H5_Layout->addWidget(ButtonConnect4);
    H5_Layout->addWidget(ButtonData);

    H6_Layout = new QHBoxLayout;
    ButtonGraphics = new QPushButton("Graphics");
    ButtonConnect5 = new QPushButton("icon");
    ButtonConnect5->setFixedWidth(50);
    H6_Layout->addWidget(ButtonConnect5);
    H6_Layout->addWidget(ButtonGraphics);

    V_Layout = new QVBoxLayout;
    V_Layout->addLayout(H2_Layout);
    V_Layout->addLayout(H3_Layout);
    V_Layout->addLayout(H4_Layout);
    V_Layout->addLayout(H5_Layout);
    V_Layout->addLayout(H6_Layout);

    H_Layout = new QHBoxLayout;
    H_Layout->addLayout(H1_Layout);
    H_Layout->addLayout(V_Layout);

    ButtonStatics->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonStatics,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuRequested(QPoint)));
    ButtonTrace->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonTrace,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuRequested(QPoint)));
    ButtonLogging->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonLogging,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuRequested(QPoint)));
    ButtonData->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonData,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuRequested(QPoint)));
    ButtonGraphics->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ButtonGraphics,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuRequested(QPoint)));


    Widget->setLayout(H_Layout);
    setCentralWidget(Widget);

}
void MainWindow::contextMenuRequested(const QPoint& point)
{
    ShowMenu = new QMenu(this);
    InsertStaticwindow = ShowMenu->addAction("InSert Statics Window");
    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    InsertGraphicsWindow = ShowMenu->addAction("Insert Graphics Window");

    ShowMenu->popup(mapToGlobal(point));

    connect(InsertStaticwindow,SIGNAL(triggered()),this,SLOT(InsertButtonStatic()));
    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(InsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(InsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(InsertButtonLog()));
    connect(InsertGraphicsWindow,SIGNAL(triggered()),this,SLOT(InsertButtonGraphics()));
}

void MainWindow::InsertButtonTrace()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Trace %1").arg(i+1));
    ButtonConnecti[i] = new QPushButton("icon");
    ButtonConnecti[i]->setFixedWidth(50);
    QHBoxLayout *HB_layout = new QHBoxLayout;
    HB_layout->addWidget(ButtonConnecti[i]);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);
    i++;
}

void MainWindow::InsertButtonStatic()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Static %1").arg(i+1));
    ButtonConnecti[i] = new QPushButton("icon");
    QHBoxLayout *HB_layout = new QHBoxLayout;
    ButtonConnecti[i]->setFixedWidth(50);
    HB_layout->addWidget(ButtonConnecti[i]);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);
    i++;
}

void MainWindow::InsertButtonData()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Data %1").arg(i+1));
    ButtonConnecti[i] = new QPushButton("icon");
    QHBoxLayout *HB_layout = new QHBoxLayout;
    ButtonConnecti[i]->setFixedWidth(50);
    HB_layout->addWidget(ButtonConnecti[i]);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);
    i++;
}

void MainWindow::InsertButtonLog()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Logging %1").arg(i+1));
    ButtonConnecti[i] = new QPushButton("icon");
    QHBoxLayout *HB_layout = new QHBoxLayout;
    ButtonConnecti[i]->setFixedWidth(50);
    HB_layout->addWidget(ButtonConnecti[i]);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);
    i++;
}

void MainWindow::InsertButtonGraphics()
{
    static int i =0;
    Button[i] = new QPushButton(tr("Graphics %1").arg(i+1));
    ButtonConnecti[i] = new QPushButton("icon");
    QHBoxLayout *HB_layout = new QHBoxLayout;
    ButtonConnecti[i]->setFixedWidth(50);
    HB_layout->addWidget(ButtonConnecti[i]);
    HB_layout->addWidget(Button[i]);
    V_Layout->addLayout(HB_layout);
    i++;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter Painter(this);
    QPen Linepen(Qt::red);
    Linepen.setWidth(2);
    Painter.setPen(Linepen);
    Painter.translate(23,23);
    Painter.drawLine(ButtonReal->pos(),ButtonConnect->pos());
    Painter.drawLine(ButtonConnect->pos(),ButtonBranch->pos());
    Painter.drawLine(ButtonBranch->pos(),ButtonConnect3->pos());
    Painter.drawLine(ButtonConnect3->pos(),ButtonLogging->pos());
    Painter.drawLine(ButtonConnect3->pos(),ButtonConnect2->pos());
    Painter.drawLine(ButtonConnect3->pos(),ButtonConnect4->pos());
    Painter.drawLine(ButtonConnect2->pos(),ButtonConnect1->pos());
    Painter.drawLine(ButtonConnect4->pos(),ButtonConnect5->pos());
    Painter.drawLine(ButtonConnect1->pos(),ButtonStatics->pos());
    Painter.drawLine(ButtonConnect2->pos(),ButtonTrace->pos());
    Painter.drawLine(ButtonConnect4->pos(),ButtonData->pos());
    Painter.drawLine(ButtonConnect5->pos(),ButtonGraphics->pos());
    event->accept();

}

MainWindow::~MainWindow()
{
    delete ui;
}
